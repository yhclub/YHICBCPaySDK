//
//  AppDelegate.h
//  ICBCPayDemo
//
//  Created by wq on 16/9/26.
//  Copyright © 2016年 wq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

