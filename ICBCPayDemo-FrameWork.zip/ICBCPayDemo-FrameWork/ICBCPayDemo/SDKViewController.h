//
//  SDKViewController.h
//  ICBCPayDemo
//
//  Created by wq on 16/10/11.
//  Copyright © 2016年 wq. All rights reserved.
// Modified by kfzx-hanw on 2020.9.2
//

#import <UIKit/UIKit.h>

@interface SDKViewController : UIViewController
@property (strong, nonatomic) NSMutableArray *urlArr; // 地址数组
@property (strong, nonatomic) UIActionSheet *actionSheet;
@end
