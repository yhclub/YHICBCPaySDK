//
//  SDKViewController.m
//  ICBCPayDemo
//
//  Created by wq on 16/10/11.
//  Copyright © 2016年 wq. All rights reserved.
// Modified by kfzx-hanw on 2020.9.2
//  测试页面首页
#import "SDKViewController.h"
#import <ICBCPaySDK/ICBCPaySDK.h>
#import "UIView+Toast.h"

@interface SDKViewController ()<ICBCPaySDKDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;
@property(nonatomic, strong) UILabel *tranDataLabel;
@property(nonatomic, strong) UILabel *merSignMsgLabel;
@property(nonatomic, strong) UILabel *merCertLabel;
@property(nonatomic, strong) UITextView *tranDataTextView;
@property(nonatomic, strong) UITextView *merSignMsgTextView;
@property(nonatomic, strong) UITextView *merCertTextView;
@property(nonatomic, strong) UITextView *mainView;//支付平台地址
@property (nonatomic,strong)UIButton *mainButton;//选择支付平台地址
@property(nonatomic, strong)UIButton *payButton;


@end

@implementation SDKViewController

-(void)viewDidLoad{
    self.title = @"1.0.0.6支付 Demo";
    self.view.backgroundColor = [UIColor whiteColor];
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,  self.view.frame.size.height)];
    _scrollView.contentSize = CGSizeMake( self.view.frame.size.width, self.view.frame.size.height);
    _tranDataLabel  = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 100, 20)];
    _tranDataTextView = [[UITextView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_tranDataLabel.frame), CGRectGetMinY(_tranDataLabel.frame),  self.view.frame.size.width - CGRectGetMaxX(_tranDataLabel.frame)-10 , 100)];
    _tranDataTextView.layer.borderColor = [UIColor grayColor].CGColor;
    _tranDataTextView.layer.borderWidth = 1;
    [_tranDataTextView setScrollEnabled:YES];
    _tranDataTextView.userInteractionEnabled = YES;
    _tranDataTextView.showsVerticalScrollIndicator = YES;
    CGSize size = CGSizeMake(400.0f, 2000.0f);
    [_tranDataTextView setContentSize:size];
    
    _merSignMsgLabel  = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(_tranDataTextView.frame)+10, CGRectGetWidth(_tranDataLabel.frame), CGRectGetHeight(_tranDataLabel.frame))];
    _merSignMsgTextView = [[UITextView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_merSignMsgLabel.frame), CGRectGetMinY(_merSignMsgLabel.frame),  self.view.frame.size.width - CGRectGetMaxX(_merSignMsgLabel.frame)-10 , 100)];
    _merSignMsgTextView.layer.borderColor = [UIColor grayColor].CGColor;
    _merSignMsgTextView.layer.borderWidth = 1;
    [_merSignMsgTextView setScrollEnabled:YES];
    _merSignMsgTextView.userInteractionEnabled = YES;
    _merSignMsgTextView.showsVerticalScrollIndicator = YES;
    [_merSignMsgTextView setContentSize:size];
    
    _merCertLabel  = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(_merSignMsgTextView.frame)+10, CGRectGetWidth(_merSignMsgLabel.frame), CGRectGetHeight(_merSignMsgLabel.frame))];
    _merCertTextView = [[UITextView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_merCertLabel.frame), CGRectGetMinY(_merCertLabel.frame),  self.view.frame.size.width - CGRectGetMaxX(_merCertLabel.frame)-10 , 100)];
    _merCertTextView.layer.borderColor = [UIColor grayColor].CGColor;
    _merCertTextView.layer.borderWidth = 1;
    [_merCertTextView setScrollEnabled:YES];
    _merCertTextView.userInteractionEnabled = YES;
    _merCertTextView.showsVerticalScrollIndicator = YES;
    [_merCertTextView setContentSize:size];

    _mainButton =  [[UIButton alloc]initWithFrame: CGRectMake(10,CGRectGetMaxY(_merCertTextView.frame)+10, self.view.frame.size.width/2-30, CGRectGetHeight(_merCertLabel.frame)+10)];
      _mainButton.layer.cornerRadius = 8.0;//8.0是圆角的弧度，根据需求自己更改
      _mainButton.layer.borderColor = [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1/1.0].CGColor;//设置边框颜色
      _mainButton.layer.borderWidth = 1.0f;//设置边框颜色
      [self.mainButton setTitle:@"点击选择支付平台地址" forState:UIControlStateNormal];
      [self.mainButton setTintColor:[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1/1.0]];
      self.mainButton.titleLabel.font = [UIFont systemFontOfSize:14];
      [self.mainButton setBackgroundColor:[UIColor colorWithRed:92/255.0 green:176/255.0 blue:126/255.0 alpha:1/1.0]];
      [self.mainButton addTarget:self action:@selector(showAddress:) forControlEvents:UIControlEventTouchUpInside];
   
    _tranDataLabel.text = @"tranData";
    _merSignMsgLabel.text = @"merSignMsg";
    _merCertLabel.text = @"merCert";
    
    self.tranDataTextView.text = @"";
    self.merSignMsgTextView.text = @"";
    self.merCertTextView.text = @"";
    _mainView = [[UITextView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_merCertLabel.frame), CGRectGetMaxY(_mainButton.frame)+10, self.view.frame.size.width - CGRectGetMaxX(_merCertLabel.frame)-10, 50)];
       _mainView.layer.borderColor = [UIColor grayColor].CGColor;
       _mainView.layer.borderWidth = 1;
       [_mainView setScrollEnabled:YES];
       _mainView.userInteractionEnabled = YES;
       _mainView.font =[UIFont systemFontOfSize:15];//内容的字体
       _mainView.showsVerticalScrollIndicator = YES;
       [_mainView setContentSize:size];
    _payButton = [[UIButton alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(_mainView.frame)+10,  self.view.frame.size.width-20, 50)];
    [_payButton setBackgroundColor:[UIColor orangeColor]];
    _payButton.layer.cornerRadius = 8.0;//8.0是圆角的弧度，根据需求自己更改
    _payButton.layer.borderColor = [UIColor redColor].CGColor;//设置边框颜色
    [_payButton setTitle:@"工银e支付" forState:UIControlStateNormal];
    [self.payButton setTintColor:[UIColor whiteColor]];
    self.payButton.titleLabel.font = [UIFont systemFontOfSize:20];
    [_payButton addTarget:self action:@selector(payButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
   
    [_scrollView addSubview:_tranDataLabel];
    [_scrollView addSubview:_merSignMsgLabel];
    [_scrollView addSubview:_merCertLabel];
    [_scrollView addSubview:_tranDataTextView];
    [_scrollView addSubview:_merSignMsgTextView];
    [_scrollView addSubview:_merCertTextView];
    [_scrollView addSubview:_mainButton];
    [_scrollView addSubview:_mainView];
    [_scrollView addSubview:_payButton];
    [self.view addSubview:_scrollView];
      _urlArr =[NSMutableArray arrayWithObjects:@"https://wechat192b2c.dccnet.com.cn:473" ,@"https://wechat198b2c.dccnet.com.cn:473",@"https://epay-2109-gn-nova-app5.sdc.cs.icbc:11452",@"https://wechat35b2c.dccnet.com.cn:11443",nil];
    UITapGestureRecognizer *recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchScrollView)];
    [recognizer setNumberOfTapsRequired:1];
    [recognizer setNumberOfTouchesRequired:1];
    [self.scrollView addGestureRecognizer:recognizer];
}

- (void)touchScrollView{
    [self.view endEditing:YES];
}

-(void)payButtonClick{
    
    NSString *urlScheme = @"dev.cn.com.icbc.iphoneRongE";
    NSString *interfaceName =@"ICBC_WAPB_B2C";
    NSString *interfaceVersion =@"1.0.0.6";
    
    NSString *tranData = [self.tranDataTextView.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *merSignMsg = [self.merSignMsgTextView.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *merCert = [self.merCertTextView.text stringByReplacingOccurrencesOfString:@" " withString:@""];

    
    NSMutableDictionary *testDic = [[NSMutableDictionary alloc] init];//接口1:商户app调用工行sdk入参
    testDic[@"urlScheme"] = urlScheme;
    testDic[@"interfaceName"] =interfaceName;
    testDic[@"interfaceVersion"] = interfaceVersion;
    testDic[@"tranData"] = tranData;
    testDic[@"merSignMsg"] = merSignMsg;
    testDic[@"merCert"] = merCert;
    
    ICBCPaySDK *shareSDK = [ICBCPaySDK sharedSdk];
    shareSDK.urlListMain = self.mainView.text;//传入支付支付平台地址
    
    shareSDK.sdkDelegate = self;
    [shareSDK presentICBCPaySDKInViewController:self  andTraderInfo:testDic];

}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.scrollView endEditing:YES];
}

- (void)paymentEndwithResultDic:(NSDictionary*)dic{
    //  接口5回调结果
    NSLog(@"返回到demo");
    NSLog(@"%@  dic",dic);
    NSLog(@"商户自行处理");
    NSString *result = [dic objectForKey:@"tranMsg"];
    NSString *tranCode = [dic objectForKey:@"tranCode"];
    NSString *errorMSg = [NSString stringWithFormat:@"trancode  %@   tranMsg:%@",tranCode,result];
    [self.view makeToast:errorMSg];
}
//弹起的是actionSheet
-(void)showAddress:(UIButton *)sender {
     self.actionSheet = [[UIActionSheet alloc] initWithTitle:@"选择支付平台地址" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil  otherButtonTitles: nil];
    
    for( NSString *title in _urlArr){
         [_actionSheet addButtonWithTitle:title];
    }
    [self.actionSheet addButtonWithTitle: @"取消"];
    [self.actionSheet setCancelButtonIndex: [_urlArr count]];
    [self.actionSheet showInView:self.view];//在当前view显示Action sheet
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString  *url =[actionSheet buttonTitleAtIndex:buttonIndex];
    if(buttonIndex!=[_urlArr count]){
    _mainView.text = url;
    }
        
}

-(void)viewWillAppear:(BOOL)animated{

}


@end
